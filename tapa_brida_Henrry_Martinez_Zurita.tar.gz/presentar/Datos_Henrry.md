# Rodamiento de bolas SKF 6204
- Dimensiones: 20x47xx14
  - **d** = 20 mm
  - **D** = 47 mm
  - **B** = 14 mm
  - **d_1** ≈ 28.8 mm
  - **D_2** ≈ 40.59 mm
  - **r_1.2** ≈ min 1 mm (dimension del chaflan)

# Retén
- **Modelo 1**: 20x30x7 Lz, tipo DBH 5133
- **Modelo 2**: 20x30x7 Lx, tipo DBH 8347

# Motor 0.5 HP a ~1450 RPM
- **Modelo**: MS712-4
  - **Voltaje**: 220/380 V
  - **Corriente**: 1.44-0.83 A
  - **Velocidad**: 1400 RPM
  - **Eficiencia**: 67%
  - **Cos φ**: 0.68
  - **Peso**: 6.3 kg

## Dimensiones de Montaje (IMB5 B5)
- **Size** : 71
- **P** = 160 mm
- **M** = 130 mm
- **N** = 110 mm
- **S** = 10 mm
- **d** = 14 mm
- **E** = 30 mm
- **T** = 3.5 mm
- **F** = 5 mm
- **G** = 11 mm
- **K** = 7 mm
- **AC** = 145 mm
- **L** = 255 mm (largo total)

## Dimensiones para la Brida (con prisma)
- **P'** = 160 mm
- **M'** = 130 mm
- **N'** = 110 mm
- **S'** = 10 mm
- **T'** = 4.5 mm (encastre hembra +1 mm)

# Selección de Acople
- **Eje motor**: 14 mm
- **Eje en reductor**: 20 mm

## Acople Plástico (Modelo VFA 0)
- **d** = 28 mm
- **L** = 75-77 mm
- **A** = 60 mm
- **D** = 46 mm
- **C_min** = 5 mm
- **C_max** = 7 mm
- **B** = 50 mm
- **E** = 35 mm
- **Construccion Tipo** : 1

## Acople Plástico (Modelo VFA 00)
- **d** = 14 mm
- **L** = 53-54 mm
- **A** = 42 mm
- **D** = 32 mm
- **C_min** = 5 mm
- **C_max** = 6 mm
- **B** = 33 mm
- **E** = 24 mm
- **Construccion Tipo** : 1

